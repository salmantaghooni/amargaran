<?php

namespace AmusementPark\Auth\Http\Controllers;

use App\Http\Controllers\Controller;
use AmusementPark\Auth\Traits\ApiResponser;

class ApiController extends Controller
{
    use ApiResponser;
}

<?php

namespace AmusementPark\Booking\Http\Controllers;

use App\Http\Controllers\Controller;
use AmusementPark\Booking\Traits\ApiResponser;

class ApiController extends Controller
{
    use ApiResponser;
}
